



<div  class="container20">

    
     
      
<video id="Test_Video" width="100%"
        controls>
    <source id="mp4_source"
            src="video.MP4"
            type="video/mp4">
    <source id="ogg_source"
            src="sample2.ogg"
            type="video/ogg">
</video>



</div>
